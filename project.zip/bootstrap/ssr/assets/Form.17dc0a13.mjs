import { _ as _sfc_main$1 } from "./AppLayout.05f9aeca.mjs";
import { Icon } from "@iconify/vue";
import { reactive, resolveComponent, mergeProps, withCtx, createVNode, toDisplayString, openBlock, createBlock, withModifiers, withDirectives, vModelText, vModelSelect, Fragment, renderList, createCommentVNode, useSSRContext } from "vue";
import { ssrRenderComponent, ssrInterpolate, ssrRenderAttr, ssrRenderList, ssrIncludeBooleanAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper.43be4956.mjs";
import "@inertiajs/inertia";
import "@inertiajs/inertia-vue3";
const _sfc_main = {
  props: ["data", "mode"],
  data() {
    return {
      loader: false,
      competitions: [],
      form: {
        mode: "Administrasi",
        administration: reactive({
          name: "",
          instance: "",
          category: null,
          competitions: "",
          user_id: this.$page.props.user.id
        }),
        participants: []
      }
    };
  },
  mounted() {
    if (this.data) {
      this.form.administration.name = this.data[0].id;
      this.form.administration.name = this.data[0].name;
      this.form.administration.instance = this.data[0].instance;
      this.form.administration.category = this.data[0].category;
      if (this.form.administration.category === "student") {
        this.competitions = [{
          label: "UiUx Competition",
          value: "uiux"
        }];
      } else if (this.form.administration.category === "colleger") {
        this.competitions = [{
          label: "Idea Bussiness",
          value: "bussiness"
        }, {
          label: "Web Competitions",
          value: "web"
        }];
      }
      setTimeout(() => {
        this.form.administration.competitions = this.data[0].competitions;
      }, 250);
      if (this.data[0].participant.length > 0) {
        this.data[0].participant.map((participant, index) => {
          let item = reactive({
            id: participant.id,
            name: participant.name,
            role: participant.role,
            identity: null,
            preview: "/img/identity/" + participant.identity
          });
          this.form.participants.push(item);
        });
      }
    }
    if (this.mode === "edit") {
      this.form.administration._method = "PATCH";
    }
  },
  components: {
    AppLayout: _sfc_main$1,
    Icon
  },
  methods: {
    onChangeCategory() {
      this.form.administration.competitions = "";
      if (this.form.administration.category === "student") {
        this.competitions = [{
          label: "UiUx Competition",
          value: "uiux"
        }];
        this.form.administration.competitions = "uiux";
      } else if (this.form.administration.category === "colleger") {
        this.competitions = [{
          label: "Idea Bussiness",
          value: "bussiness"
        }, {
          label: "Web Competitions",
          value: "web"
        }];
        this.form.administration.competitions = "bussiness";
      }
    },
    onSubmitAdministration() {
      let url = this.mode === "create" ? this.route("administration.store") : this.route("administration.update", this.data[1]);
      if (this.mode === "detail") {
        this.form.mode = "Peserta";
      } else {
        this.loader = true;
        this.$inertia.post(url, this.form.administration, {
          onFinish: (visit) => {
            this.loader = false;
          },
          onSuccess: (page) => {
            this.form.mode = "Peserta";
          }
        });
      }
    },
    onBackFromParticipantForm() {
      this.form.mode = "Administrasi";
    },
    addParticipant() {
      if (this.form.participants.length < 3) {
        let participant = reactive({
          id: null,
          name: null,
          role: this.form.participants.length === 0 ? "leader" : "member",
          identity: null,
          preview: null
        });
        this.form.participants.push(participant);
      }
    },
    removeParticipant(index) {
      if (this.form.participants[index].id !== null) {
        this.$inertia.delete(this.route("participant.destroy", this.form.participants[index].id), {
          onSuccess: (page) => {
            this.form.participants.splice(index, 1);
          }
        });
      } else
        this.form.participants.splice(index, 1);
    },
    onChangeIdentityFile(e, index) {
      let file = e.target.files[0];
      this.form.participants[index].identity = file;
      this.form.participants[index].preview = URL.createObjectURL(file);
    },
    onSubmit() {
      if (this.form.participants.length > 0) {
        this.loader = true;
        for (let i = 0; i < this.form.participants.length; i++) {
          if (this.form.participants[i].name && this.form.participants[i].identity) {
            let url = this.form.participants[i].id === null ? this.route("participant.store") : this.route("participant.update", this.form.participants[i].id);
            let formdata = new FormData();
            formdata.append("name", this.form.participants[i].name);
            formdata.append("role", this.form.participants[i].role);
            formdata.append("identity", this.form.participants[i].identity);
            formdata.append("administration_id", this.data[0].id);
            if (this.form.participants[i].id !== null)
              formdata.append("_method", "PATCH");
            axios.post(url, formdata).then((response) => {
              this.loader = false;
              if (i + 1 === this.form.participants.length) {
                window.location.href = "/dashboard";
              }
            });
          } else {
            if (i + 1 === this.form.participants.length) {
              window.location.href = "/dashboard";
            }
          }
        }
      }
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_AppLayout = resolveComponent("AppLayout");
  const _component_Icon = resolveComponent("Icon");
  _push(ssrRenderComponent(_component_AppLayout, mergeProps({
    title: "Dashboard",
    administration: [$data.form.administration, ""]
  }, _attrs), {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="py-24 min-h-screen bg-gradient-to-br from-blue-500 to-cyan-500"${_scopeId}><div class="max-w-7xl mx-auto px-8 sm:px-6 lg:px-8"${_scopeId}><div class="bg-white overflow-hidden shadow-xl sm:rounded-lg rounded-xl"${_scopeId}><div class="p-6 border-b"${_scopeId}><h1 class="text-2xl font-bold"${_scopeId}>${ssrInterpolate($data.form.mode)}</h1></div>`);
        if ($data.form.mode === "Administrasi") {
          _push2(`<form${_scopeId}><div class="bg-gray-50 py-6 px-12 space-y-4"${_scopeId}><div class="form-control w-full"${_scopeId}><label class="label"${_scopeId}><span class="label-text font-bold text-cyan-700 text-lg"${_scopeId}>Nama Tim</span></label><input maxlength="100" required type="text"${ssrRenderAttr("value", $data.form.administration.name)} placeholder="eg. Tim Eskobar Dev" class="input hover:border-cyan-500 w-full"${_scopeId}></div><div class="form-control w-full"${_scopeId}><label class="label"${_scopeId}><span class="label-text font-bold text-cyan-700 text-lg"${_scopeId}>Asal Instansi</span></label><input maxlength="100" required type="text"${ssrRenderAttr("value", $data.form.administration.instance)} placeholder="eg. Politeknik Elektronika Negeri Surabaya" class="input hover:border-cyan-500 w-full"${_scopeId}></div><div class="form-control w-full"${_scopeId}><label class="label"${_scopeId}><span class="label-text font-bold text-cyan-700 text-lg"${_scopeId}>Kategori Instansi</span></label><select required class="input hover:border-cyan-500 w-full"${_scopeId}><option${ssrRenderAttr("value", null)}${_scopeId}>Pilih Kategori Instansi</option><option value="colleger"${_scopeId}>Kampus (Mahasiswa)</option><option value="student"${_scopeId}>Sekolah (Siswa)</option></select></div>`);
          if ($data.form.administration.category) {
            _push2(`<div class="form-control w-full"${_scopeId}><label class="label"${_scopeId}><span class="label-text font-bold text-cyan-700 text-lg"${_scopeId}>Kategori Lomba</span></label><select required class="input hover:border-cyan-500 w-full"${_scopeId}><!--[-->`);
            ssrRenderList($data.competitions, (item, index) => {
              _push2(`<option${ssrRenderAttr("value", item.value)}${_scopeId}>${ssrInterpolate(item.label)}</option>`);
            });
            _push2(`<!--]--></select></div>`);
          } else {
            _push2(`<!---->`);
          }
          _push2(`<div class="text-right space-x-3"${_scopeId}><a${ssrRenderAttr("href", _ctx.route("dashboard"))} type="button" class="btn btn-ghost px-5"${_scopeId}>Batal</a><button${ssrIncludeBooleanAttr($data.loader) ? " disabled" : ""} type="submit" class="btn btn-info px-5"${_scopeId}>`);
          if ($data.loader) {
            _push2(`<div${_scopeId}> Memproses </div>`);
          } else {
            _push2(`<div${_scopeId}> Selanjutnya </div>`);
          }
          _push2(`</button></div></div></form>`);
        } else {
          _push2(`<!---->`);
        }
        if ($data.form.mode === "Peserta") {
          _push2(`<form${_scopeId}><div class="bg-gray-50 py-6 px-12 space-y-4"${_scopeId}>`);
          if ($data.form.participants.length > 0) {
            _push2(`<div${_scopeId}><!--[-->`);
            ssrRenderList($data.form.participants, (participant, index) => {
              _push2(`<div class="p-6 shadow-lg rounded-xl my-4 bg-white relative"${_scopeId}><div class="absolute right-0 top-0"${_scopeId}><button type="button" class="btn bg-white border-0 hover:text-red-600 hover:bg-gray-200 text-red-500"${_scopeId}>`);
              _push2(ssrRenderComponent(_component_Icon, {
                icon: "eva:close-fill",
                class: "text-2xl"
              }, null, _parent2, _scopeId));
              _push2(`</button></div><div class="form-control w-full"${_scopeId}><label class="label"${_scopeId}><span class="label-text font-bold text-cyan-700 text-lg"${_scopeId}>${ssrInterpolate(index == 0 ? "Ketua Tim" : "Anggota Tim " + index)}</span></label><input maxlength="100" required type="text"${ssrRenderAttr("value", $data.form.participants[index].name)} placeholder="eg. Mohammad Fulan" class="input hover:border-cyan-500 border-px border-gray-200 w-full"${_scopeId}></div><div class="form-control w-full"${_scopeId}><label class="label"${_scopeId}><span class="label-text font-bold text-cyan-700 text-lg"${_scopeId}>Foto Kartu Tanda ${ssrInterpolate($data.form.administration.category === "student" ? " Pelajar" : " Mahasiswa")}</span></label><input${ssrRenderAttr("id", `participant-${index}`)} required type="file" accept="image/png, image/jpg, image/jpeg" placeholder="eg. Mohammad Fulan" class="hidden"${_scopeId}><label${ssrRenderAttr("for", `participant-${index}`)} class="border-dashed border-2 overflow-hidden hover:bg-cyan-200 transition-all cursor-pointer rounded-xl border-cyan-500 text-cyan-700"${_scopeId}>`);
              if ($data.form.participants[index].identity !== null || $data.form.participants[index].preview !== null) {
                _push2(`<div${_scopeId}><img class="w-full"${ssrRenderAttr("src", $data.form.participants[index].preview)} alt="Preview KTP/KTM"${_scopeId}></div>`);
              } else {
                _push2(`<div class="flex p-8 justify-center gap-3 items-center"${_scopeId}>`);
                _push2(ssrRenderComponent(_component_Icon, {
                  icon: "akar-icons:image",
                  class: "text-3xl"
                }, null, _parent2, _scopeId));
                _push2(`<h1${_scopeId}>Klik untuk menambahkan</h1></div>`);
              }
              _push2(`</label></div></div>`);
            });
            _push2(`<!--]--></div>`);
          } else {
            _push2(`<!---->`);
          }
          if ($data.form.participants.length < 3) {
            _push2(`<button type="button" class="btn text-neutral hover:text-white w-full text-center bg-white"${_scopeId}> Tambah Peserta </button>`);
          } else {
            _push2(`<!---->`);
          }
          _push2(`<div class="text-right space-x-3"${_scopeId}><button type="button" class="btn btn-ghost px-5"${_scopeId}>Administrasi</button><button${ssrIncludeBooleanAttr($data.loader) ? " disabled" : ""} type="submit" class="btn btn-info px-5"${_scopeId}>`);
          if ($data.loader) {
            _push2(`<div${_scopeId}> Memproses </div>`);
          } else {
            _push2(`<div${_scopeId}> Selanjutnya </div>`);
          }
          _push2(`</button></div></div></form>`);
        } else {
          _push2(`<!---->`);
        }
        _push2(`</div></div></div>`);
      } else {
        return [
          createVNode("div", { class: "py-24 min-h-screen bg-gradient-to-br from-blue-500 to-cyan-500" }, [
            createVNode("div", { class: "max-w-7xl mx-auto px-8 sm:px-6 lg:px-8" }, [
              createVNode("div", { class: "bg-white overflow-hidden shadow-xl sm:rounded-lg rounded-xl" }, [
                createVNode("div", { class: "p-6 border-b" }, [
                  createVNode("h1", { class: "text-2xl font-bold" }, toDisplayString($data.form.mode), 1)
                ]),
                $data.form.mode === "Administrasi" ? (openBlock(), createBlock("form", {
                  key: 0,
                  onSubmit: withModifiers(($event) => $options.onSubmitAdministration(), ["prevent"])
                }, [
                  createVNode("div", { class: "bg-gray-50 py-6 px-12 space-y-4" }, [
                    createVNode("div", { class: "form-control w-full" }, [
                      createVNode("label", { class: "label" }, [
                        createVNode("span", { class: "label-text font-bold text-cyan-700 text-lg" }, "Nama Tim")
                      ]),
                      withDirectives(createVNode("input", {
                        maxlength: "100",
                        required: "",
                        type: "text",
                        "onUpdate:modelValue": ($event) => $data.form.administration.name = $event,
                        placeholder: "eg. Tim Eskobar Dev",
                        class: "input hover:border-cyan-500 w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, $data.form.administration.name]
                      ])
                    ]),
                    createVNode("div", { class: "form-control w-full" }, [
                      createVNode("label", { class: "label" }, [
                        createVNode("span", { class: "label-text font-bold text-cyan-700 text-lg" }, "Asal Instansi")
                      ]),
                      withDirectives(createVNode("input", {
                        maxlength: "100",
                        required: "",
                        type: "text",
                        "onUpdate:modelValue": ($event) => $data.form.administration.instance = $event,
                        placeholder: "eg. Politeknik Elektronika Negeri Surabaya",
                        class: "input hover:border-cyan-500 w-full"
                      }, null, 8, ["onUpdate:modelValue"]), [
                        [vModelText, $data.form.administration.instance]
                      ])
                    ]),
                    createVNode("div", { class: "form-control w-full" }, [
                      createVNode("label", { class: "label" }, [
                        createVNode("span", { class: "label-text font-bold text-cyan-700 text-lg" }, "Kategori Instansi")
                      ]),
                      withDirectives(createVNode("select", {
                        onChange: ($event) => $options.onChangeCategory(),
                        required: "",
                        "onUpdate:modelValue": ($event) => $data.form.administration.category = $event,
                        class: "input hover:border-cyan-500 w-full"
                      }, [
                        createVNode("option", { value: null }, "Pilih Kategori Instansi"),
                        createVNode("option", { value: "colleger" }, "Kampus (Mahasiswa)"),
                        createVNode("option", { value: "student" }, "Sekolah (Siswa)")
                      ], 40, ["onChange", "onUpdate:modelValue"]), [
                        [vModelSelect, $data.form.administration.category]
                      ])
                    ]),
                    $data.form.administration.category ? (openBlock(), createBlock("div", {
                      key: 0,
                      class: "form-control w-full"
                    }, [
                      createVNode("label", { class: "label" }, [
                        createVNode("span", { class: "label-text font-bold text-cyan-700 text-lg" }, "Kategori Lomba")
                      ]),
                      withDirectives(createVNode("select", {
                        required: "",
                        "onUpdate:modelValue": ($event) => $data.form.administration.competitions = $event,
                        class: "input hover:border-cyan-500 w-full"
                      }, [
                        (openBlock(true), createBlock(Fragment, null, renderList($data.competitions, (item, index) => {
                          return openBlock(), createBlock("option", {
                            key: index,
                            value: item.value
                          }, toDisplayString(item.label), 9, ["value"]);
                        }), 128))
                      ], 8, ["onUpdate:modelValue"]), [
                        [vModelSelect, $data.form.administration.competitions]
                      ])
                    ])) : createCommentVNode("", true),
                    createVNode("div", { class: "text-right space-x-3" }, [
                      createVNode("a", {
                        href: _ctx.route("dashboard"),
                        type: "button",
                        class: "btn btn-ghost px-5"
                      }, "Batal", 8, ["href"]),
                      createVNode("button", {
                        disabled: $data.loader,
                        type: "submit",
                        class: "btn btn-info px-5"
                      }, [
                        $data.loader ? (openBlock(), createBlock("div", { key: 0 }, " Memproses ")) : (openBlock(), createBlock("div", { key: 1 }, " Selanjutnya "))
                      ], 8, ["disabled"])
                    ])
                  ])
                ], 40, ["onSubmit"])) : createCommentVNode("", true),
                $data.form.mode === "Peserta" ? (openBlock(), createBlock("form", { key: 1 }, [
                  createVNode("div", { class: "bg-gray-50 py-6 px-12 space-y-4" }, [
                    $data.form.participants.length > 0 ? (openBlock(), createBlock("div", { key: 0 }, [
                      (openBlock(true), createBlock(Fragment, null, renderList($data.form.participants, (participant, index) => {
                        return openBlock(), createBlock("div", {
                          class: "p-6 shadow-lg rounded-xl my-4 bg-white relative",
                          key: `participant-${index}`
                        }, [
                          createVNode("div", { class: "absolute right-0 top-0" }, [
                            createVNode("button", {
                              onClick: ($event) => $options.removeParticipant(index),
                              type: "button",
                              class: "btn bg-white border-0 hover:text-red-600 hover:bg-gray-200 text-red-500"
                            }, [
                              createVNode(_component_Icon, {
                                icon: "eva:close-fill",
                                class: "text-2xl"
                              })
                            ], 8, ["onClick"])
                          ]),
                          createVNode("div", { class: "form-control w-full" }, [
                            createVNode("label", { class: "label" }, [
                              createVNode("span", { class: "label-text font-bold text-cyan-700 text-lg" }, toDisplayString(index == 0 ? "Ketua Tim" : "Anggota Tim " + index), 1)
                            ]),
                            withDirectives(createVNode("input", {
                              maxlength: "100",
                              required: "",
                              type: "text",
                              "onUpdate:modelValue": ($event) => $data.form.participants[index].name = $event,
                              placeholder: "eg. Mohammad Fulan",
                              class: "input hover:border-cyan-500 border-px border-gray-200 w-full"
                            }, null, 8, ["onUpdate:modelValue"]), [
                              [vModelText, $data.form.participants[index].name]
                            ])
                          ]),
                          createVNode("div", { class: "form-control w-full" }, [
                            createVNode("label", { class: "label" }, [
                              createVNode("span", { class: "label-text font-bold text-cyan-700 text-lg" }, "Foto Kartu Tanda " + toDisplayString($data.form.administration.category === "student" ? " Pelajar" : " Mahasiswa"), 1)
                            ]),
                            createVNode("input", {
                              id: `participant-${index}`,
                              onChange: ($event) => $options.onChangeIdentityFile($event, index),
                              required: "",
                              type: "file",
                              accept: "image/png, image/jpg, image/jpeg",
                              placeholder: "eg. Mohammad Fulan",
                              class: "hidden"
                            }, null, 40, ["id", "onChange"]),
                            createVNode("label", {
                              for: `participant-${index}`,
                              class: "border-dashed border-2 overflow-hidden hover:bg-cyan-200 transition-all cursor-pointer rounded-xl border-cyan-500 text-cyan-700"
                            }, [
                              $data.form.participants[index].identity !== null || $data.form.participants[index].preview !== null ? (openBlock(), createBlock("div", { key: 0 }, [
                                createVNode("img", {
                                  class: "w-full",
                                  src: $data.form.participants[index].preview,
                                  alt: "Preview KTP/KTM"
                                }, null, 8, ["src"])
                              ])) : (openBlock(), createBlock("div", {
                                key: 1,
                                class: "flex p-8 justify-center gap-3 items-center"
                              }, [
                                createVNode(_component_Icon, {
                                  icon: "akar-icons:image",
                                  class: "text-3xl"
                                }),
                                createVNode("h1", null, "Klik untuk menambahkan")
                              ]))
                            ], 8, ["for"])
                          ])
                        ]);
                      }), 128))
                    ])) : createCommentVNode("", true),
                    $data.form.participants.length < 3 ? (openBlock(), createBlock("button", {
                      key: 1,
                      type: "button",
                      onClick: ($event) => $options.addParticipant(),
                      class: "btn text-neutral hover:text-white w-full text-center bg-white"
                    }, " Tambah Peserta ", 8, ["onClick"])) : createCommentVNode("", true),
                    createVNode("div", { class: "text-right space-x-3" }, [
                      createVNode("button", {
                        onClick: $options.onBackFromParticipantForm,
                        type: "button",
                        class: "btn btn-ghost px-5"
                      }, "Administrasi", 8, ["onClick"]),
                      createVNode("button", {
                        disabled: $data.loader,
                        onClick: ($event) => $options.onSubmit(),
                        type: "submit",
                        class: "btn btn-info px-5"
                      }, [
                        $data.loader ? (openBlock(), createBlock("div", { key: 0 }, " Memproses ")) : (openBlock(), createBlock("div", { key: 1 }, " Selanjutnya "))
                      ], 8, ["disabled", "onClick"])
                    ])
                  ])
                ])) : createCommentVNode("", true)
              ])
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Administration/Form.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Form = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Form as default
};
