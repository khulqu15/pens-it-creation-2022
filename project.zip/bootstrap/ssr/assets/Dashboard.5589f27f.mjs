import { _ as _sfc_main$2 } from "./AppLayout.05f9aeca.mjs";
import { W as Welcome } from "./Welcome.ef8b6a31.mjs";
import { Icon } from "@iconify/vue";
import { reactive, resolveComponent, useSSRContext, mergeProps, withCtx, createVNode, openBlock, createBlock } from "vue";
import { ssrRenderAttrs, ssrRenderAttr, ssrRenderList, ssrInterpolate, ssrRenderClass, ssrRenderComponent } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper.43be4956.mjs";
import "@inertiajs/inertia";
import "@inertiajs/inertia-vue3";
const _sfc_main$1 = {
  props: ["administrations"],
  name: "TeamTable",
  data() {
    return {
      input: reactive({
        name: "",
        category: "",
        sort: "",
        competition: ""
      }),
      competitions: [{
        label: "UiUx Competition",
        value: "uiux"
      }, {
        label: "Idea Bussiness",
        value: "bussiness"
      }, {
        label: "Web Competition",
        value: "web"
      }],
      selected: 0
    };
  },
  mounted() {
    console.log(this.administrations);
  },
  components: {
    Icon
  },
  methods: {
    onSearch() {
      this.$inertia.get(this.route("dashboard"), this.input, {
        preserveState: true,
        preserveScroll: true
      });
    },
    set_url_page(link) {
      if (link !== null) {
        console.log(link);
        let str = Object.entries(this.input).map(([key, val]) => `${key}=${val}`).join("&");
        return link + "&" + str;
      }
    },
    confirmAdministration() {
      let value = this.administrations.data[this.selected].is_confirmed ? 0 : 1;
      this.$inertia.post(this.route("administration.confirm", this.administrations.data[this.selected].id), {
        is_confirmed: value
      }, {
        preserveScroll: true,
        preserveState: true,
        onSuccess: (page) => {
          document.getElementById("confirmation_modal_label").click();
        }
      });
    },
    confirmElemination() {
      let value = this.administrations.data[this.selected].elimination.is_eliminated ? 0 : 1;
      this.$inertia.post(this.route("elimination.confirm", this.administrations.data[this.selected].elimination.id), {
        is_eliminated: value
      }, {
        preserveScroll: true,
        preserveState: true,
        onSuccess: (page) => {
          document.getElementById("elemination_modal_label").click();
        }
      });
    },
    confirmPayment() {
      let value = this.administrations.data[this.selected].payment_confirmation ? 0 : 1;
      this.$inertia.post(this.route("administration.payment.confirmation", this.administrations.data[this.selected].id), {
        payment_confirmation: value
      }, {
        preserveScroll: true,
        preserveState: true,
        onSuccess: (page) => {
          document.getElementById("payment_modal_label").click();
        }
      });
    },
    onDestroy() {
      this.$inertia.delete(this.route("administration.destroy", this.administrations.data[this.selected].id), {
        preserveScroll: true,
        preserveState: true,
        onSuccess: (page) => {
          document.getElementById("delete_modal_label").click();
        }
      });
    }
  }
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_Icon = resolveComponent("Icon");
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="grid md:grid-cols-4 grid-cols-2 space-y-2 gap-3 mb-4"><div><input${ssrRenderAttr("value", $data.input.name)} type="text" placeholder="Cari nama tim" class="input w-full"></div><div><select class="input w-full"><option value="">Semua Kategori</option><option value="colleger">Mahasiswa</option><option value="student">Siswa</option></select></div><div><select class="input w-full"><option value="">Semua Lomba</option><!--[-->`);
  ssrRenderList($data.competitions, (item, index) => {
    _push(`<option${ssrRenderAttr("value", item.value)}>${ssrInterpolate(item.label)}</option>`);
  });
  _push(`<!--]--></select></div><div><select class="input w-full"><option value="">Paling baru</option><option value="asc">Paling lama</option></select></div></div>`);
  if ($props.administrations.data.length > 0) {
    _push(`<div class="overflow-x-auto overflow-y-visible"><table class="table w-full"><thead><tr><th></th><th>Name</th><th>Instansi</th><th>Kategori</th><th>Lomba</th><th>Keanggotaan</th><th>Administrasi</th><th>Penyisihan</th><th>Pembayaran</th><th>Aksi</th></tr></thead><tbody><!--[-->`);
    ssrRenderList($props.administrations.data, (item, index) => {
      _push(`<tr><th>${ssrInterpolate(($props.administrations.current_page - 1) * $props.administrations.per_page + index + 1)}</th><td>${ssrInterpolate(item.name)}</td><td>${ssrInterpolate(item.instance)}</td><td>${ssrInterpolate(item.category === "colleger" ? "Mahasiswa" : "Siswa")}</td><td>${ssrInterpolate(item.competitions === "uiux" ? "UiUx Competition" : item.competition === "web" ? "Web Competition" : "Idea Bussiness")}</td><td>${ssrInterpolate(item.participant.length)} Anggota</td><td><span class="${ssrRenderClass([{ "badge-success": item.is_confirmed === 1, "badge-error": item.is_confirmed === 0 }, "badge"])}">${ssrInterpolate(item.is_confirmed === 1 ? "Confirmed" : "Uniconfirmed")}</span></td><td>`);
      if (item.elimination !== null) {
        _push(`<span class="${ssrRenderClass([{ "badge-success": item.elimination.is_eliminated === 1, "badge-error": item.elimination.is_eliminated === 0 }, "badge"])}">${ssrInterpolate(item.elimination.is_eliminated === 1 ? "Passed" : "Un-pass")}</span>`);
      } else {
        _push(`<!---->`);
      }
      _push(`</td><td><span class="${ssrRenderClass([{ "badge-success": item.payment_confirmation === 1, "badge-error": item.payment_confirmation === 0 }, "badge"])}">${ssrInterpolate(item.payment === null ? "Unpaid" : "Paid")}</span></td><td class="relative"><div class="dropdown dropdown-left dropdown-start"><label tabindex="0" class="btn btn-ghost p-2 border border-gray-100 text-black">`);
      _push(ssrRenderComponent(_component_Icon, {
        icon: "clarity:ellipsis-vertical-line",
        class: "text-xl"
      }, null, _parent));
      _push(`</label><ul tabindex="0" class="absolute z-50 dropdown-content menu p-2 text-sm shadow bg-base-100 rounded-box w-52"><li><label for="confirmation_modal">Konfirmasi Administrasi</label></li>`);
      if (item.elimination) {
        _push(`<li><label for="elimination_modal">Lolos Penyisihan</label></li>`);
      } else {
        _push(`<!---->`);
      }
      if (item.payment !== null) {
        _push(`<li><label for="payment_modal">Konfirmasi Pembayaran</label></li>`);
      } else {
        _push(`<!---->`);
      }
      _push(`<li><label for="delete_modal" class="bg-red-100 text-red-700">Hapus</label></li></ul></div></td></tr>`);
    });
    _push(`<!--]--></tbody></table><input type="checkbox" id="confirmation_modal" class="modal-toggle"><label for="confirmation_modal" id="confirmation_modal_label" class="modal cursor-pointer"><label class="modal-box w-11/12 max-w-5xl" for=""><h3 class="font-bold text-lg">Konfirmasi Administrasi</h3><div class="form-control w-full"><label class="label"><span class="label-text font-bold text-cyan-700">Nama Tim</span></label><input maxlength="100" disabled required type="text" readonly${ssrRenderAttr("value", $props.administrations.data[$data.selected].name)} placeholder="eg. Tim Eskobar Dev" class="input hover:border-cyan-500 w-full"></div><div class="form-control w-full"><label class="label"><span class="label-text font-bold text-cyan-700">Asal Instansi</span></label><input maxlength="100" disabled required type="text"${ssrRenderAttr("value", $props.administrations.data[$data.selected].instance)} placeholder="eg. Politeknik Elektronika Negeri Surabaya" class="input hover:border-cyan-500 w-full"></div><div class="form-control w-full"><label class="label"><span class="label-text font-bold text-cyan-700">Asal Instansi</span></label><select required disabled class="input border border-gray-200 hover:border-cyan-500 w-full"><option value="">Pilih Kategori Instansi</option><option value="colleger">Kampus (Mahasiswa)</option><option value="student">Sekolah (Siswa)</option></select></div>`);
    if ($props.administrations.data[$data.selected].participant.length > 0) {
      _push(`<div><!--[-->`);
      ssrRenderList($props.administrations.data[$data.selected].participant, (participant, index) => {
        _push(`<div class="p-6 shadow-lg rounded-xl my-4 bg-white relative"><div class="form-control w-full"><div class="label"><span class="label-text font-bold text-cyan-700 text-lg">${ssrInterpolate(index == 0 ? "Ketua Tim" : "Anggota Tim " + index)}</span></div><input maxlength="100" required type="text"${ssrRenderAttr("value", participant.name)} placeholder="eg. Mohammad Fulan" class="input hover:border-cyan-500 border-px border-gray-200 w-full"></div><div class="form-control w-full"><div class="label"><span class="label-text font-bold text-cyan-700 text-lg">Foto Kartu Tanda ${ssrInterpolate($props.administrations.data[$data.selected].category === "student" ? " Pelajar" : " Mahasiswa")}</span></div><div class="border-dashed border-2 overflow-hidden hover:bg-cyan-200 transition-all cursor-pointer rounded-xl border-cyan-500 text-cyan-700">`);
        if (participant.identity) {
          _push(`<div><img class="w-full"${ssrRenderAttr("src", `/img/identity/${participant.identity}`)} alt="Preview KTP/KTM"></div>`);
        } else {
          _push(`<!---->`);
        }
        _push(`</div></div></div>`);
      });
      _push(`<!--]--></div>`);
    } else {
      _push(`<!---->`);
    }
    _push(`<div class="modal-action"><label for="confirmation_modal" class="btn btn-ghost">Batal</label><button class="${ssrRenderClass([{ "btn-error": $props.administrations.data[$data.selected].is_confirmed, "btn-info": $props.administrations.data[$data.selected].is_confirmed === 0 }, "btn"])}">${ssrInterpolate($props.administrations.data[$data.selected].is_confirmed ? "Tidak jadi" : "Konfirmasi")}</button></div></label></label><input type="checkbox" id="elimination_modal" class="modal-toggle"><label for="elimination_modal" id="elemination_modal_label" class="modal cursor-pointer"><label class="modal-box w-11/12 max-w-5xl relative" for=""><div class="flex justify-between items-center mb-5"><h3 class="text-2xl font-bold mb-3">Penyisihan</h3><div class="text-3xl flex gap-3 my-4">`);
    _push(ssrRenderComponent(_component_Icon, { icon: "icon-park:github-one" }, null, _parent));
    _push(ssrRenderComponent(_component_Icon, { icon: "logos:figma" }, null, _parent));
    _push(ssrRenderComponent(_component_Icon, { icon: "logos:google-drive" }, null, _parent));
    _push(ssrRenderComponent(_component_Icon, { icon: "logos:gitlab" }, null, _parent));
    _push(ssrRenderComponent(_component_Icon, { icon: "logos:heroku-icon" }, null, _parent));
    _push(`</div></div>`);
    if ($props.administrations.data[$data.selected].elimination) {
      _push(`<div class="form-control w-full"><input readonly disabled maxlength="255" id="elimination-input"${ssrRenderAttr("value", $props.administrations.data[$data.selected].elimination.link)} required type="text" placeholder="eg. www.domain.com" class="input w-full shadow rounde-xl"><div class="grid grid-cols-2 gap-3"><label for="elimination_modal" class="btn btn-ghost mt-4 w-full">Tutup</label><button class="${ssrRenderClass([{ "btn-error": $props.administrations.data[$data.selected].elimination.is_eliminated, "btn-info": $props.administrations.data[$data.selected].elimination.is_eliminated === 0 }, "btn mt-4 w-full"])}">${ssrInterpolate($props.administrations.data[$data.selected].elimination.is_eliminated ? "Tidak jadi" : "Konfirmasi")}</button></div></div>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</label></label><input type="checkbox" id="payment_modal" class="modal-toggle"><label for="payment_modal" id="payment_modal_label" class="modal cursor-pointer"><label class="modal-box w-11/12 max-w-5xl relative" for=""><h3 class="text-2xl font-bold mb-3">Konfirmasi Pembayaran</h3><div class="form-control w-full"><div class="w-full border-dashed border-2 overflow-hidden hover:bg-cyan-200 transition-all cursor-pointer rounded-xl border-cyan-500 text-cyan-700">`);
    if ($props.administrations.data[$data.selected].payment !== null) {
      _push(`<div><img class="w-full"${ssrRenderAttr("src", `/img/payment/${$props.administrations.data[$data.selected].payment}`)} alt="Preview Pembayaran"></div>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div><div class="grid grid-cols-2 gap-3"><label for="payment-modal" class="btn btn-ghost mt-4 w-full">Tutup</label><button class="${ssrRenderClass([{ "btn-error": $props.administrations.data[$data.selected].payment_confirmation, "btn-info": $props.administrations.data[$data.selected].payment_confirmation === 0 }, "btn mt-4 w-full"])}">${ssrInterpolate($props.administrations.data[$data.selected].payment_confirmation ? "Tidak jadi" : "Konfirmasi")}</button></div></div></label></label><input type="checkbox" id="delete_modal" class="modal-toggle"><label for="delete_modal" id="delete_modal_label" class="modal cursor-pointer"><label class="modal-box relative" for=""><h3 class="text-2xl font-bold mb-3">Hapus Administrasi ?</h3><div class="form-control w-full"><div class="grid grid-cols-2 gap-3"><label for="delete_modal" class="btn btn-ghost mt-4 w-full">Tutup</label><button class="btn mt-4 w-full btn-error">Hapus</button></div></div></label></label><div class="text-right"><div class="btn-group mt-4 ml-auto inline-block">`);
    if ($props.administrations.prev_page_url !== null) {
      _push(`<a class="btn btn-ghost"${ssrRenderAttr("href", $options.set_url_page($props.administrations.prev_page_url))}>\xAB</a>`);
    } else {
      _push(`<!---->`);
    }
    _push(`<button class="btn btn-ghost">${ssrInterpolate($props.administrations.current_page)}</button>`);
    if ($props.administrations.next_page_url !== null) {
      _push(`<a class="btn btn-ghost"${ssrRenderAttr("href", $options.set_url_page($props.administrations.next_page_url))}>\xBB</a>`);
    } else {
      _push(`<!---->`);
    }
    _push(`</div></div></div>`);
  } else {
    _push(`<div><div class="alert text-white alert-error shadow-lg"><div class="flex w-full justify-between items-center"><div class="flex gap-3"><svg xmlns="http://www.w3.org/2000/svg" class="stroke-current flex-shrink-0 h-6 w-6" fill="none" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg><span>Tidak ada data! data tim tidak ditemukan.</span></div><div><button class="btn bg-white border-0 text-red-600 ml-auto">Reset</button></div></div></div></div>`);
  }
  _push(`</div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/TeamTable.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const TeamTable = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main = {
  props: ["administration", "elimination", "administrations", "users"],
  components: {
    AppLayout: _sfc_main$2,
    Welcome,
    TeamTable
  },
  data() {
    return {};
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_AppLayout = resolveComponent("AppLayout");
  const _component_Welcome = resolveComponent("Welcome");
  const _component_team_table = resolveComponent("team-table");
  _push(ssrRenderComponent(_component_AppLayout, mergeProps({
    title: "Dashboard",
    administration: $props.administration
  }, _attrs), {
    default: withCtx((_, _push2, _parent2, _scopeId) => {
      if (_push2) {
        _push2(`<div class="py-24 min-h-screen bg-gradient-to-br from-blue-500 to-cyan-500"${_scopeId}><div class="max-w-7xl mx-auto px-8 sm:px-6 lg:px-8"${_scopeId}><div class="bg-white shadow-xl sm:rounded-lg rounded-xl"${_scopeId}>`);
        if (_ctx.$page.props.user.role === "user") {
          _push2(`<div${_scopeId}>`);
          _push2(ssrRenderComponent(_component_Welcome, {
            administration: $props.administration,
            elimination: $props.elimination
          }, null, _parent2, _scopeId));
          _push2(`</div>`);
        } else {
          _push2(`<div${_scopeId}><div class="grid p-6 grid-cols-2 gap-4 border-b"${_scopeId}><div${_scopeId}><a${ssrRenderAttr("href", _ctx.route("dashboard"))} class="btn w-full border btn-info"${_scopeId}>Team</a></div><div${_scopeId}><a${ssrRenderAttr("href", _ctx.route("dashboard.user"))} class="btn w-full border btn-ghost"${_scopeId}>User</a></div></div><div class="bg-gray-50 p-6"${_scopeId}>`);
          _push2(ssrRenderComponent(_component_team_table, { administrations: $props.administrations }, null, _parent2, _scopeId));
          _push2(`</div></div>`);
        }
        _push2(`</div></div></div>`);
      } else {
        return [
          createVNode("div", { class: "py-24 min-h-screen bg-gradient-to-br from-blue-500 to-cyan-500" }, [
            createVNode("div", { class: "max-w-7xl mx-auto px-8 sm:px-6 lg:px-8" }, [
              createVNode("div", { class: "bg-white shadow-xl sm:rounded-lg rounded-xl" }, [
                _ctx.$page.props.user.role === "user" ? (openBlock(), createBlock("div", { key: 0 }, [
                  createVNode(_component_Welcome, {
                    administration: $props.administration,
                    elimination: $props.elimination
                  }, null, 8, ["administration", "elimination"])
                ])) : (openBlock(), createBlock("div", { key: 1 }, [
                  createVNode("div", { class: "grid p-6 grid-cols-2 gap-4 border-b" }, [
                    createVNode("div", null, [
                      createVNode("a", {
                        href: _ctx.route("dashboard"),
                        class: "btn w-full border btn-info"
                      }, "Team", 8, ["href"])
                    ]),
                    createVNode("div", null, [
                      createVNode("a", {
                        href: _ctx.route("dashboard.user"),
                        class: "btn w-full border btn-ghost"
                      }, "User", 8, ["href"])
                    ])
                  ]),
                  createVNode("div", { class: "bg-gray-50 p-6" }, [
                    createVNode(_component_team_table, { administrations: $props.administrations }, null, 8, ["administrations"])
                  ])
                ]))
              ])
            ])
          ])
        ];
      }
    }),
    _: 1
  }, _parent));
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Pages/Dashboard.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Dashboard = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Dashboard as default
};
