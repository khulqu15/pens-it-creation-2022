import { useSSRContext, mergeProps, reactive, resolveComponent } from "vue";
import { ssrRenderAttrs, ssrInterpolate, ssrRenderComponent, ssrRenderClass, ssrRenderAttr } from "vue/server-renderer";
import { _ as _export_sfc } from "./_plugin-vue_export-helper.43be4956.mjs";
import { Icon } from "@iconify/vue";
const _sfc_main$1 = {
  props: ["administration"]
};
function _sfc_ssrRender$1(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  _push(`<div${ssrRenderAttrs(mergeProps({ class: "flex items-center pt-12 gap-5" }, _attrs))}><div><img src="/img/himit-fest-logo.png" class="w-20 h-20"></div><div><span class="my-font text-4xl">${ssrInterpolate($props.administration[0] ? $props.administration[0].category === "student" ? "UiUx" : "Web" : "Himit")} Competition 2022</span></div></div>`);
}
const _sfc_setup$1 = _sfc_main$1.setup;
_sfc_main$1.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/ApplicationLogo.vue");
  return _sfc_setup$1 ? _sfc_setup$1(props, ctx) : void 0;
};
const ApplicationLogo = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["ssrRender", _sfc_ssrRender$1]]);
const _sfc_main = {
  props: ["administration", "elimination"],
  components: {
    Icon,
    ApplicationLogo
  },
  data() {
    return {
      loader: false,
      form: {
        elimination: reactive({
          link: "",
          administration_id: null
        }),
        payment: reactive({
          payment: null,
          administration_id: null,
          preview: null
        })
      }
    };
  },
  mounted() {
    if (this.administration[0]) {
      this.form.elimination.administration_id = this.administration[0].id;
      this.form.payment.administration_id = this.administration[0].id;
      if (this.administration[0].elimination)
        this.form.elimination.link = this.administration[0].elimination.link;
      if (this.administration[0].payment)
        this.form.payment.preview = "/img/payment/" + this.administration[0].payment;
      this.form.payment.payment = this.administration[0].payment;
    }
  },
  methods: {
    onChangePaymentFile(e) {
      let file = e.target.files[0];
      this.form.payment.payment = file;
      this.form.payment.preview = URL.createObjectURL(file);
    },
    onEliminationSubmit() {
      this.loader = true;
      if (this.administration[0].elimination !== null)
        this.form.elimination._method = "PATCH";
      let url = this.administration[0].elimination === null ? this.route("elimination.store") : this.route("elimination.update", this.elimination[1]);
      this.$inertia.post(url, this.form.elimination, {
        onFinish: (visit) => {
          this.loader = true;
        },
        onSuccess: (page) => {
          document.getElementById("elimination-modal-label").click();
        }
      });
    },
    onPaymentSubmit() {
      this.loader = true;
      this.$inertia.post(this.route("administration.payment", this.administration[1]), this.form.payment, {
        onFinish: (visit) => {
          this.loader = true;
        },
        onSuccess: (page) => {
          document.getElementById("payment-modal-label").click();
        }
      });
    }
  }
};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs, $props, $setup, $data, $options) {
  const _component_ApplicationLogo = resolveComponent("ApplicationLogo");
  const _component_Icon = resolveComponent("Icon");
  _push(`<div${ssrRenderAttrs(_attrs)}><div class="p-6 sm:px-6 bg-white border-b border-gray-200"><div>`);
  _push(ssrRenderComponent(_component_ApplicationLogo, {
    administration: $props.administration,
    class: "block h-12 w-auto"
  }, null, _parent));
  _push(`</div><div class="mt-12 text-gray-500">`);
  if ($props.administration[0] && $props.administration[0].category === "colleger") {
    _push(`<span> Web Design Competition adalah perlombaan yang diperuntukan bagi mahasiswa/I aktif program sarjana maupun diploma di perguruan tinggi swasta atau negeri di seluruh Indonesia dengan menguji kreativitasnya dalam mendesain web. Keberadaan lomba ini diharapkan dapat menjadi wadah bagi mahasiswa/I dalam menuangkan ide-ide </span>`);
  } else {
    _push(`<span> Kompetisi User Interface (UI)/User Experience (UX) Design adalah kompetisi desain antarmuka sistem/produk yang berorientasi kepada kenyamanan dan kemudahan pengguna (user) dalam menggunakan sistem/produk tersebut. </span>`);
  }
  _push(`</div></div><div class="bg-gray-200 bg-opacity-25 grid grid-cols-1 md:grid-cols-1"><div class="p-6 border-b"><div class="flex justify-between items-center"><div class="mt-2 text-sm text-gray-500"><div class="flex items-center">`);
  _push(ssrRenderComponent(_component_Icon, {
    icon: "akar-icons:folder-add",
    class: "text-3xl"
  }, null, _parent));
  _push(`<div class="ml-4 text-lg text-gray-600 leading-7 font-semibold"><a href="#">Administrasi `);
  if ($props.administration[0] !== null) {
    _push(`<div class="${ssrRenderClass([{ "badge-error": $props.administration[0].is_confirmed === 0, "badge-success": $props.administration[0].is_confirmed }, "badge gap-2"])}">${ssrInterpolate($props.administration[0] && $props.administration[0].is_confirmed === 0 ? "Menunggu Konfirmasi" : "Sudah Dikonfirmasi")}</div>`);
  } else {
    _push(`<div class="badge gap-2 badge-ghost"> Belum diisi </div>`);
  }
  _push(`</a></div></div><p class="mt-3 ml-12">Lengkapi berkas - berkas pendaftaran sesuai persyaratan dan upload pada akunmu</p></div><div>`);
  if ($props.administration[0] === null) {
    _push(`<a${ssrRenderAttr("href", _ctx.route("administration.create"))} class="btn bg-yellow-500 border-0 hover:bg-yellow-700 text-black pt-1 px-6 mt-3">Lengkapi</a>`);
  } else {
    _push(`<a${ssrRenderAttr("href", $props.administration[0].is_confirmed === 1 ? "#" : _ctx.route("administration.edit", $props.administration[1]))} class="${ssrRenderClass([{ "btn-disabled opacity-50": $props.administration[0].is_confirmed === 1 }, "btn bg-green-500 border-0 hover:bg-green-700 text-black pt-1 px-6 mt-3"])}">${ssrInterpolate($props.administration[0].participant.length < 2 ? "Lengkapi" : "Edit")}</a>`);
  }
  _push(`</div></div></div><div class="p-6 border-b"><div class="flex justify-between items-center"><div class="mt-2 text-sm text-gray-500"><div class="flex items-center">`);
  _push(ssrRenderComponent(_component_Icon, {
    icon: "akar-icons:double-sword",
    class: "text-3xl"
  }, null, _parent));
  _push(`<div class="ml-4 text-lg text-gray-600 leading-7 space-x-1 font-semibold"><a href="#">Penyisihan `);
  if ($props.administration[0] && $props.administration[0].elimination !== null) {
    _push(`<div class="${ssrRenderClass([{ "badge-error": $props.administration[0].elimination.is_eliminated === 0, "badge-success": $props.administration[0].elimination.is_eliminated === 1 }, "badge gap-2"])}">${ssrInterpolate($props.administration[0].elimination.is_eliminated === 0 ? "Belum Tereliminasi" : "Lolos Penyisihan")}</div>`);
  } else {
    _push(`<div class="badge gap-2 badge-ghost"> Belum diisi </div>`);
  }
  _push(`</a></div></div><p class="mt-3 ml-12">Babak penyisihan untuk menentukan kamu masuk babak final</p></div>`);
  if ($props.administration[0] && $props.administration[0].is_confirmed) {
    _push(`<div>`);
    if ($props.administration[0]) {
      _push(`<label${ssrRenderAttr("for", $props.administration[0].elimination === null || $props.administration[0].elimination.is_eliminated !== 1 ? "elimination-modal" : "")} id="elimination-modal-label" class="${ssrRenderClass([{ "bg-yellow-500 hover:bg-yellow-700": $props.administration[0].elimination === null, "bg-green-500 hover:bg-green-700": $props.administration[0].elimination !== null, "btn-disabled opacity-50": $props.administration[0].elimination && $props.administration[0].elimination.is_eliminated === 1 }, "btn border-0 text-black pt-1 px-6 mt-3"])}">${ssrInterpolate($props.administration[0].elimination === null ? "Lengkapi" : "Edit")}</label>`);
    } else {
      _push(`<!---->`);
    }
    _push(`<input type="checkbox" id="elimination-modal" class="modal-toggle"><label for="elimination-modal" class="modal cursor-pointer"><label class="modal-box relative" for=""><div class="flex justify-between items-center mb-5"><h3 class="text-2xl font-bold mb-3">Penyisihan</h3><div class="text-3xl flex gap-3 my-4">`);
    _push(ssrRenderComponent(_component_Icon, { icon: "icon-park:github-one" }, null, _parent));
    _push(ssrRenderComponent(_component_Icon, { icon: "logos:figma" }, null, _parent));
    _push(ssrRenderComponent(_component_Icon, { icon: "logos:google-drive" }, null, _parent));
    _push(ssrRenderComponent(_component_Icon, { icon: "logos:gitlab" }, null, _parent));
    _push(ssrRenderComponent(_component_Icon, { icon: "logos:heroku-icon" }, null, _parent));
    _push(`</div></div><p class="text-gray-500 mb-5">Kamu bisa mengirimkan link github, figma, drive atau yang lainnya.</p><form><div class="form-control w-full"><input maxlength="255" id="elimination-input"${ssrRenderAttr("value", $data.form.elimination.link)} required type="text" placeholder="eg. www.domain.com" class="input w-full shadow rounde-xl"><div class="grid grid-cols-2 gap-3"><label for="elimination-modal" class="btn btn-ghost mt-4 w-full">Tutup</label><button class="btn btn-warning mt-4 w-full">Simpan</button></div></div></form></label></label></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div><div class="p-6"><div class="flex justify-between items-center"><div class="mt-2 text-sm text-gray-500"><div class="flex items-center">`);
  _push(ssrRenderComponent(_component_Icon, {
    icon: "akar-icons:money",
    class: "text-3xl"
  }, null, _parent));
  _push(`<div class="ml-4 text-lg text-gray-600 leading-7 font-semibold"><a href="#">Pembayaran `);
  if ($props.administration[0] !== null && $props.administration[0].payment !== null) {
    _push(`<div class="${ssrRenderClass([{ "badge-error": $props.administration[0].payment_confirmation === 0, "badge-success": $props.administration[0].payment_confirmation }, "badge gap-2"])}">${ssrInterpolate($props.administration[0].payment_confirmation === 0 ? "Menunggu Konfirmasi" : "Sudah Dikonfirmasi")}</div>`);
  } else {
    _push(`<div class="badge gap-2 badge-ghost"> Belum diisi </div>`);
  }
  _push(`</a></div></div><p class="mt-3 ml-12">Lakukan pembayaran sesuai jenis lomba dan upload bukti pembayaran pada akunmu</p></div>`);
  if ($props.administration[0] && $props.administration[0].elimination !== null) {
    _push(`<div>`);
    if ($props.administration[0].elimination.is_eliminated === 1) {
      _push(`<label id="payment-modal-label"${ssrRenderAttr("for", $props.administration[0].payment_confirmation === 0 ? "payment-modal" : "")} class="${ssrRenderClass([{ "bg-yellow-500 hover:bg-yellow-700": $props.administration[0].payment === null, "bg-green-500 hover:bg-green-700": $props.administration[0].payment, "btn-disabled opacity-50": $props.administration[0] && $props.administration[0].payment_confirmation === 1 }, "btn bg-yellow-500 border-0 hover:bg-yellow-700 text-black pt-1 px-6 mt-3"])}">${ssrInterpolate($props.administration[0].payment === null ? "Lengkapi" : "Edit")}</label>`);
    } else {
      _push(`<!---->`);
    }
    _push(`<input type="checkbox" id="payment-modal" class="modal-toggle"><label for="payment-modal" class="modal cursor-pointer"><label class="modal-box relative" for=""><h3 class="text-xl font-bold mb-3">Kirimkan Bukti Pembayaran</h3><form enctype="multipart/form-data"><div class="form-control w-full"><input id="payment-input" required type="file" accept="image/png, image/jpg, image/jpeg" placeholder="eg. Mohammad Fulan" class="hidden"><label for="payment-input" class="w-full border-dashed border-2 overflow-hidden hover:bg-cyan-200 transition-all cursor-pointer rounded-xl border-cyan-500 text-cyan-700">`);
    if ($data.form.payment.preview === null && $data.form.payment.payment === null) {
      _push(`<div class="flex p-8 justify-center gap-3 items-center">`);
      _push(ssrRenderComponent(_component_Icon, {
        icon: "akar-icons:image",
        class: "text-3xl"
      }, null, _parent));
      _push(`<h1>Klik untuk menambahkan</h1></div>`);
    } else {
      _push(`<div><img class="w-full"${ssrRenderAttr("src", $data.form.payment.preview)} alt="Preview Pembayaran"></div>`);
    }
    _push(`</label><div class="grid grid-cols-2 gap-3"><label for="payment-modal" class="btn btn-ghost mt-4 w-full">Tutup</label><button class="btn btn-warning mt-4 w-full">Simpan</button></div></div></form></label></label></div>`);
  } else {
    _push(`<!---->`);
  }
  _push(`</div></div></div></div>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/Welcome.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const Welcome = /* @__PURE__ */ _export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]);
export {
  Welcome as W
};
