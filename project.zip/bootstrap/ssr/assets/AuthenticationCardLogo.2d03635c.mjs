import { unref, mergeProps, withCtx, createVNode, createTextVNode, useSSRContext } from "vue";
import { ssrRenderComponent } from "vue/server-renderer";
import { Link } from "@inertiajs/inertia-vue3";
const _sfc_main = {
  __name: "AuthenticationCardLogo",
  __ssrInlineRender: true,
  setup(__props) {
    return (_ctx, _push, _parent, _attrs) => {
      _push(ssrRenderComponent(unref(Link), mergeProps({ href: "/" }, _attrs), {
        default: withCtx((_, _push2, _parent2, _scopeId) => {
          if (_push2) {
            _push2(`<div class="flex items-center justify-center gap-4"${_scopeId}><div class="relative"${_scopeId}><h1 class="my-font text-8xl my-6 text-yellow-600 absolute top-2 left-1"${_scopeId}>HIMIT</h1><h1 class="my-font text-8xl my-6 text-cyan-700 relative"${_scopeId}>HIMIT</h1></div><div class="relative"${_scopeId}><h1 class="my-font text-5xl my-6 text-yellow-600 absolute top-1 left-1"${_scopeId}>FEST <br${_scopeId}> 2022</h1><h1 class="my-font text-5xl my-6 text-cyan-700 relative"${_scopeId}>FEST <br${_scopeId}> 2022</h1></div></div>`);
          } else {
            return [
              createVNode("div", { class: "flex items-center justify-center gap-4" }, [
                createVNode("div", { class: "relative" }, [
                  createVNode("h1", { class: "my-font text-8xl my-6 text-yellow-600 absolute top-2 left-1" }, "HIMIT"),
                  createVNode("h1", { class: "my-font text-8xl my-6 text-cyan-700 relative" }, "HIMIT")
                ]),
                createVNode("div", { class: "relative" }, [
                  createVNode("h1", { class: "my-font text-5xl my-6 text-yellow-600 absolute top-1 left-1" }, [
                    createTextVNode("FEST "),
                    createVNode("br"),
                    createTextVNode(" 2022")
                  ]),
                  createVNode("h1", { class: "my-font text-5xl my-6 text-cyan-700 relative" }, [
                    createTextVNode("FEST "),
                    createVNode("br"),
                    createTextVNode(" 2022")
                  ])
                ])
              ])
            ];
          }
        }),
        _: 1
      }, _parent));
    };
  }
};
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("resources/js/Components/AuthenticationCardLogo.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
export {
  _sfc_main as _
};
