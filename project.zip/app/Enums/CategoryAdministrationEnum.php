<?php

namespace App\Enums;

enum CategoryAdministrationEnum:string
{
    case STUDENT = 'student';
    case COLLEGER = 'colleger';
}
